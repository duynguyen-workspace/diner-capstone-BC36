// primitive type:  string, number, boolean , null, undefined

// toán tử so sánh : >, >=, <, <=, =, !=, === ,!==
// biểu thức so sánh

console.log(5 > 2); // true
console.log(5 >= 5); // true
console.log(5 < 2); // false
console.log(5 <= 2); // false
console.log(5 == 5); // true
console.log(4 != 5); // true

console.log(4 === "4"); // false
console.log(5 !== "5"); // true

// toán tử logic : !, && , ||

var a = true;

console.log(!!!a);

// biểu thức logic
console.log(1 > 2 && 3 > 4 && 4 > 1);

console.log(1 > 2 || 3 > 4 || 4 > 1); // true

// câu điều kiện
// biểu thức điều kiện: giá trị, biểu thức so sanh, bt logic

// if(biểu thức điều kiện){
// code sẽ chạy nếu biểu thức điều kiện đúng
// }

var n = 5;

if (n < 0) {
  n = n * -1;
  console.log("chuyển n sang số dương");
} else {
  console.log(n, "Đã là số dương");
}

var k = 3;

if (k % 2 === 0) {
  console.log(k, "là số chẵn");
} else {
  console.log(k, "là số l");
}

/**
 * INPUT: số tiền phải trả(creditCardBalance), số tiền đã thanh toán(payment)
 *
 * PROCESS:
 *     1. lấy input , creditCardBalance = 10000000, payment = 40000000
 *     2. tính tiền nợ balance = số tiền phải trả - số đã thanh toán
 *     3. nếu tiền nợ > 0, tính tiền phạt, penalty = 1.5% của tiền nợ
 *     4, nếu tiền nợ = 0, báo đã thanh toán toàn bộ tiền
 *
 *
 *
 *
 * OUTPUT: tính tiền phạt nếu có
 */

var creditCardBalance = 1000;
var payment = 500;
var penalty = 0;
var balance = creditCardBalance - payment;

if (balance > 0) {
  penalty = (1.5 / 100) * balance;
  console.log(penalty);
} else {
  console.log("Bạn đã thanh toán đầy đủ");
}

// bài tập: slide 15, 25, 21

var workingHours = 50;
var wage = 10;
var totalWage = 0;

if (workingHours <= 40) {
  totalWage = workingHours * wage;
} else {
  totalWage = 40 * wage + (workingHours - 40) * wage * 1.5;
}

console.log(totalWage);

var fullName = "Hiếu Đặng";
var math = 8;
var physic = 8;
var chemistry = 8;
var result = "";

var gpa = (math + physic + chemistry) / 3;

if (gpa >= 8.5) result = "Giỏi";
else if (gpa >= 6.5) result = "Khá";
else if (gpa >= 5) result = "Trung Bình";
else result = "Yếu";

console.log(fullName, result);

var product = "iphone 14";
var quantity = 120;
var price = 1800;
var total = 0;

if (quantity < 50) {
  total = quantity * price;
} else if (quantity <= 100) {
  total = 50 * price + (quantity - 50) * price * 0.92;
} else {
  total = 50 * price + 50 * price * 0.92 + (quantity - 100) * price * 0.88;
}

// switch case

// ex: viết chương trình nhập vào tháng , in ra tháng đó có bao nhiêu ngày
// vd:  tháng 3 => 31 ngày

// if (month === 1) {
//   console.log("Tháng 1 có 31 ngày");
// } else if (month === 2) {
//   console.log("Tháng 2 có 28 ngày");
// } else if (month === 3) {
//   console.log("Tháng 3 có 31 ngày");
// } else if (month === 4) {
//   console.log("Tháng 4 có 30 ngày");
// }

var month = 1;

switch (month) {
  case 1:
  case 3:
  case 5:
  case 7:
  case 8:
  case 10:
  case 12:
    console.log("31 ngày");
    break;

  case 2:
    console.log("28 ngày");
    break;

  case 4:
  case 6:
  case 9:
  case 11:
    console.log(" 30 ngày");
    break;

  default:
    console.log("Tháng ko hợp lệ");
}
